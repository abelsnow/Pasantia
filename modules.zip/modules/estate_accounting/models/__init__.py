# -*- coding: utf-8 -*-

from . import estate_property_inherit
from . import account_move_inherit